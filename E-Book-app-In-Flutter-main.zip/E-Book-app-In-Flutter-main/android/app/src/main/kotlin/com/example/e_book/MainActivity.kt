package com.example.e_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
