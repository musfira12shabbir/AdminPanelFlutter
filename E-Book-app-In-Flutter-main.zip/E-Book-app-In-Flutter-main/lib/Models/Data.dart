import 'package:e_book/Models/BookModel.dart';

var categoryData = [
  {
    "icon": "Assets/Icons/heart.svg",
    "lebel": "Romance",
  },
  {
    "icon": "Assets/Icons/plane.svg",
    "lebel": "Travel",
  },
  {
    "icon": "Assets/Icons/world.svg",
    "lebel": "Documentary",
  },
  {
    "icon": "Assets/Icons/heart.svg",
    "lebel": "Love Story",
  },
];

var bookData = [
  BookModel(
      id: "1",
      title:
          "Boundraties and thi is my first book and and thi is my first book and ",
      description:
          "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum",
      aboutAuthor: "hi my name is Nitish Roy and i have written this book",
      audioLen: "20",
      author: "Nitish Roy",
      coverUrl: "Assets/Images/boundraries.jpg",
      rating: "4.2",
      category: "Documentary",
      numberofRating: "10,",
      price: 100,
      pages: 234,
      language: "ENG",
      bookurl:
          "https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf"),
  BookModel(
      id: "2",
      title: "Daily Stoice",
      description:
          "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum",
      aboutAuthor: "hi my name is Nitish Roy and i have written this book",
      audioLen: "20",
      author: "Nitish Roy",
      coverUrl: "Assets/Images/daily stoic.jpg",
      rating: "4.2",
      category: "Documentary",
      price: 100,
      numberofRating: "10,",
      language: "ENG",
      pages: 234,
      bookurl:
          "https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf"),
  BookModel(
      id: "3",
      title: "Give and Take",
      description:
          "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum",
      aboutAuthor: "hi my name is Nitish Roy and i have written this book",
      audioLen: "20",
      author: "Nitish Roy",
      coverUrl: "Assets/Images/Give and Take.jpg",
      rating: "4.2",
      category: "Documentary",
      numberofRating: "10,",
      price: 100,
      language: "ENG",
      pages: 234,
      bookurl:
          "https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf"),
  BookModel(
    id: "4",
    title: "When the moon split",
    description:
        "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum",
    aboutAuthor: "hi my name is Nitish Roy and i have written this book",
    audioLen: "20",
    author: "Nitish Roy",
    coverUrl: "Assets/Images/When the moon split.jpg",
    rating: "4.2",
    category: "Documentary",
    price: 100,
    pages: 234,
    language: "ENG",
    numberofRating: "10,",
    bookurl:
        "https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf",
  )
];
