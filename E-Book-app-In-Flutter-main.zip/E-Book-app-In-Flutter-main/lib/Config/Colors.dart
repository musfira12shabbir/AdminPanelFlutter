import 'package:flutter/material.dart';

const primaryColor = Color(0xFF0057FF);
const secondryColor = Color(0xFF00C236);
const backgroudColor = Color(0xFFFFFFFF);
const fontColor = Color(0xFF000000);
const lebelColor = Color(0xFF6B6B6B);
const secondLebelColor = Color(0xffC6C6C6);
