import 'package:flutter/material.dart';

var myDrawer = Drawer(
  child: Column(
    children: [
      ListTile(
        title: Text("CALL"),
        onTap: () {},
      )
    ],
  ),
);
